public class mainClass{
	
	public static void main(String args[]){

	DataProcessor dp = new DataProcessor();

	HashTable  hashTable = new HashTable(70,dp.getVoters());

	


	}
}